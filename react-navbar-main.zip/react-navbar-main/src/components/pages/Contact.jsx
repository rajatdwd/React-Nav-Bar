import React from "react";

export const Contact = () => {
  return <h1>Contact</h1>;
};
